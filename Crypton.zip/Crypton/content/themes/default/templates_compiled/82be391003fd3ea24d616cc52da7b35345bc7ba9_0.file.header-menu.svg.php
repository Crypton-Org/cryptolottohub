<?php
/* Smarty version 3.1.40, created on 2022-04-09 09:52:48
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/header-menu.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62515770573383_08997031',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '82be391003fd3ea24d616cc52da7b35345bc7ba9' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/header-menu.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62515770573383_08997031 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="384pt" viewBox="0 -53 384 384" width="384pt" xmlns="http://www.w3.org/2000/svg"><path d="m368 154.667969h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/><path d="m368 32h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/><path d="m368 277.332031h-352c-8.832031 0-16-7.167969-16-16s7.167969-16 16-16h352c8.832031 0 16 7.167969 16 16s-7.167969 16-16 16zm0 0"/></svg><?php }
}
