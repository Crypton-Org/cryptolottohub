<?php
/* Smarty version 3.1.40, created on 2022-04-09 10:12:09
  from '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/test_email.txt' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62515bf94a5573_55622005',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd1f092e21b78e542dbf3dabaee9c137b115711c' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/test_email.txt',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62515bf94a5573_55622005 (Smarty_Internal_Template $_smarty_tpl) {
echo __("Hi");?>
,

<?php echo __("This is a test email");?>


<?php echo $_smarty_tpl->tpl_vars['system']->value['system_title'];?>
 <?php echo __("Team");
}
}
