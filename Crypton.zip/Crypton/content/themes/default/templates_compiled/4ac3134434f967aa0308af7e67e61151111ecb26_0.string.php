<?php
/* Smarty version 3.1.40, created on 2022-04-09 12:22:57
  from '4ac3134434f967aa0308af7e67e61151111ecb26' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62517aa124a8f6_82055096',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62517aa124a8f6_82055096 (Smarty_Internal_Template $_smarty_tpl) {
?><div>
<h1 style="text-align: center;"><span style="font-size: x-large;"><u>A</u><u>bout Us !</u></span></h1>
<h3 style="text-align: center;"><span style="font-weight: normal;"><span style="font-size: large;">Hello Friends Welcome To CRYPTOLOTTOHUB</span></span></h3>
<p style="text-align: center;">&nbsp;</p>
<p style="font-size: 18px;">CRYPTOLOTTOHUB is a Professional Social Community Platform. Here we will provide you only interesting content, which you will like very much.</p>
<p style="text-align: center;">&nbsp;</p>
<p style="font-size: 18px;">We're dedicated to providing you the best of Social Community, with a focus on dependability and Earn Cryptocurrency.<br /><br /></p>
<p style="font-size: 18px;">We're working to turn our passion for Social Community into a booming online website. We hope you enjoy our Social Community as much as we enjoy offering them to you.</p>
<div style="text-align: center;">&nbsp;</div>
<div style="text-align: center;">
<h3>We will keep posting more important posts on my Website for all of you. Please give your support and love.</h3>
</div>
<div style="text-align: center;">
<h3>Thanks For Visiting Our Site</h3>
</div>
<div style="text-align: center;">
<h4>Contact Us !</h4>
</div>
</div><?php }
}
