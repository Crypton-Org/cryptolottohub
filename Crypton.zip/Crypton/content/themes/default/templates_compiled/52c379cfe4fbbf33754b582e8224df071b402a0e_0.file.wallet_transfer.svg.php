<?php
/* Smarty version 3.1.40, created on 2022-04-09 10:53:09
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/wallet_transfer.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62516595a8a505_21293777',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '52c379cfe4fbbf33754b582e8224df071b402a0e' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/wallet_transfer.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62516595a8a505_21293777 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Layer_3" enable-background="new 0 0 64 64" height="512" viewBox="0 0 64 64" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m20 62h-14c-2.209 0-4-1.791-4-4v-30c0-2.209 1.791-4 4-4h14c2.209 0 4 1.791 4 4v30c0 2.209-1.791 4-4 4z" fill="#8892a0"/><path d="m2 30h22v24h-22z" fill="#85bddf"/><path d="m2 51.049c9.49-3.487 16.747-11.352 19.143-21.049h-19.143z" fill="#b6d7ec"/><path d="m58 62h-14c-2.209 0-4-1.791-4-4v-30c0-2.209 1.791-4 4-4h14c2.209 0 4 1.791 4 4v30c0 2.209-1.791 4-4 4z" fill="#8892a0"/><path d="m40 30h22v24h-22z" fill="#85bddf"/><path d="m40 51.049c9.49-3.487 16.747-11.352 19.143-21.049h-19.143z" fill="#b6d7ec"/><path d="m18 50h10v4l6-6-6-6v4h-10z" fill="#f7d881"/><path d="m46 39h-10v4l-6-6 6-6v4h10z" fill="#f7d881"/><path d="m18 2h28v16h-28z" fill="#96cc7f"/><path d="m18 2v12.776c1.141.147 2.309.224 3.5.224 10.097 0 18.641-5.469 21.489-13z" fill="#c0e0b2"/><path d="m22 8 2-2h16l2 2v4l-2 2h-16l-2-2z" fill="#ebf7fe"/><circle cx="32" cy="10" fill="#96cc7f" r="4"/><g><path d="m11 57h4v2h-4z" fill="#fff"/></g><g><path d="m49 57h4v2h-4z" fill="#fff"/></g><g><path d="m49 34h8v2h-8z" fill="#fff"/></g><g><path d="m49 38h10v2h-10z" fill="#fff"/></g><g><path d="m7 48h8v2h-8z" fill="#fff"/></g><g><path d="m5 44h10v2h-10z" fill="#fff"/></g><g><path d="m7 21h2v3h-2z" fill="#a0a8b3"/></g><g><path d="m7 17h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m7 13h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m7 9h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m11 9h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m15 9h3v2h-3z" fill="#a0a8b3"/></g><g><path d="m55 21h2v3h-2z" fill="#a0a8b3"/></g><g><path d="m55 17h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m55 13h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m55 9h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m51 9h2v2h-2z" fill="#a0a8b3"/></g><g><path d="m46 9h3v2h-3z" fill="#a0a8b3"/></g></g></svg><?php }
}
