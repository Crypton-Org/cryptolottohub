<?php
/* Smarty version 3.1.40, created on 2022-04-09 09:52:48
  from '/home/nfrd7fewr696/public_html/content/themes/default/templates/__svg_icons.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6251577053f5b1_92794204',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8feeda0f133d1f069e889c0ebe97b95bd570e328' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/templates/__svg_icons.tpl',
      1 => 1642469398,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../images/svg/2co.svg' => 1,
    'file:../images/svg/paypal.svg' => 1,
    'file:../images/svg/credit_card.svg' => 1,
    'file:../images/svg/alipay.svg' => 1,
    'file:../images/svg/bank.svg' => 1,
    'file:../images/svg/bitcoin.svg' => 1,
    'file:../images/svg/photos.svg' => 1,
    'file:../images/svg/videos.svg' => 1,
    'file:../images/svg/audios.svg' => 1,
    'file:../images/svg/files.svg' => 1,
    'file:../images/svg/sun.svg' => 1,
    'file:../images/svg/night.svg' => 1,
    'file:../images/svg/sunrise.svg' => 1,
    'file:../images/svg/scroll_desktop.svg' => 1,
    'file:../images/svg/scroll_mobile.svg' => 1,
    'file:../images/svg/chat.svg' => 1,
    'file:../images/svg/settings.svg' => 1,
    'file:../images/svg/dashboard.svg' => 1,
    'file:../images/svg/24_hours.svg' => 1,
    'file:../images/svg/trending.svg' => 1,
    'file:../images/svg/memories.svg' => 1,
    'file:../images/svg/language.svg' => 1,
    'file:../images/svg/posts_discover.svg' => 1,
    'file:../images/svg/popularity.svg' => 1,
    'file:../images/svg/posts_colored.svg' => 1,
    'file:../images/svg/posts_recent.svg' => 1,
    'file:../images/svg/social_share.svg' => 1,
    'file:../images/svg/youtube.svg' => 1,
    'file:../images/svg/piggy_bank.svg' => 1,
    'file:../images/svg/adult.svg' => 1,
    'file:../images/svg/watermark.svg' => 1,
    'file:../images/svg/jobs.svg' => 1,
    'file:../images/svg/google_recaptcha.svg' => 1,
    'file:../images/svg/censored.svg' => 1,
    'file:../images/svg/fingerprint.svg' => 1,
    'file:../images/svg/hacker.svg' => 1,
    'file:../images/svg/firewall.svg' => 1,
    'file:../images/svg/chat_status.svg' => 1,
    'file:../images/svg/chat_seen.svg' => 1,
    'file:../images/svg/chat_typing.svg' => 1,
    'file:../images/svg/call_video.svg' => 1,
    'file:../images/svg/call_audio.svg' => 1,
    'file:../images/svg/aws_s3.svg' => 1,
    'file:../images/svg/digitalocean.svg' => 1,
    'file:../images/svg/ftp.svg' => 1,
    'file:../images/svg/sms.svg' => 1,
    'file:../images/svg/twilio.svg' => 1,
    'file:../images/svg/infobip.svg' => 1,
    'file:../images/svg/bulksms.svg' => 1,
    'file:../images/svg/msg91.svg' => 1,
    'file:../images/svg/email.svg' => 1,
    'file:../images/svg/email_notifications.svg' => 1,
    'file:../images/svg/email_smtp.svg' => 1,
    'file:../images/svg/login.svg' => 1,
    'file:../images/svg/ssl.svg' => 1,
    'file:../images/svg/smile.svg' => 1,
    'file:../images/svg/map.svg' => 1,
    'file:../images/svg/polls.svg' => 1,
    'file:../images/svg/gif.svg' => 1,
    'file:../images/svg/wall_posts.svg' => 1,
    'file:../images/svg/verification.svg' => 1,
    'file:../images/svg/age_limit.svg' => 1,
    'file:../images/svg/getting_started.svg' => 1,
    'file:../images/svg/account_activation.svg' => 1,
    'file:../images/svg/pro_packages.svg' => 1,
    'file:../images/svg/newsletter.svg' => 1,
    'file:../images/svg/info_download.svg' => 1,
    'file:../images/svg/delete_user.svg' => 1,
    'file:../images/svg/registration.svg' => 1,
    'file:../images/svg/invitation.svg' => 1,
    'file:../images/svg/invite_friend.svg' => 1,
    'file:../images/svg/wallet.svg' => 1,
    'file:../images/svg/resolution.svg' => 1,
    'file:../images/svg/website_live.svg' => 1,
    'file:../images/svg/website_public.svg' => 1,
    'file:../images/svg/directory.svg' => 1,
    'file:../images/svg/contat_us.svg' => 1,
    'file:../images/svg/adblock.svg' => 1,
    'file:../images/svg/cookie.svg' => 1,
    'file:../images/svg/browser_notifications.svg' => 1,
    'file:../images/svg/noty_notifications.svg' => 1,
    'file:../images/svg/profile_notifications.svg' => 1,
    'file:../images/svg/gifts.svg' => 1,
    'file:../images/svg/poke.svg' => 1,
    'file:../images/svg/onesignal.svg' => 1,
    'file:../images/svg/like.svg' => 1,
    'file:../images/svg/comment.svg' => 1,
    'file:../images/svg/share.svg' => 1,
    'file:../images/svg/developers.svg' => 1,
    'file:../images/svg/affiliates.svg' => 1,
    'file:../images/svg/withdrawal.svg' => 1,
    'file:../images/svg/wallet_transfer.svg' => 1,
    'file:../images/svg/pages.svg' => 1,
    'file:../images/svg/groups.svg' => 1,
    'file:../images/svg/events.svg' => 1,
    'file:../images/svg/blogs.svg' => 1,
    'file:../images/svg/market.svg' => 1,
    'file:../images/svg/products.svg' => 1,
    'file:../images/svg/forums.svg' => 1,
    'file:../images/svg/ads.svg' => 1,
    'file:../images/svg/movies.svg' => 1,
    'file:../images/svg/games.svg' => 1,
    'file:../images/svg/find_people.svg' => 1,
    'file:../images/svg/saved.svg' => 1,
    'file:../images/svg/articles.svg' => 1,
    'file:../images/svg/boosted_pages.svg' => 1,
    'file:../images/svg/boosted_posts.svg' => 1,
    'file:../images/svg/newsfeed.svg' => 1,
    'file:../images/svg/share_plugin.svg' => 1,
    'file:../images/svg/personal_info.svg' => 1,
    'file:../images/svg/followings.svg' => 1,
    'file:../images/svg/friends.svg' => 1,
    'file:../images/svg/followers.svg' => 1,
    'file:../images/svg/search.svg' => 1,
    'file:../images/svg/folder.svg' => 1,
    'file:../images/svg/database.svg' => 1,
    'file:../images/svg/full_backup.svg' => 1,
    'file:../images/svg/album.svg' => 1,
    'file:../images/svg/write_article.svg' => 1,
    'file:../images/svg/music_file.svg' => 1,
    'file:../images/svg/night_mode.svg' => 1,
    'file:../images/svg/user_night_mode.svg' => 1,
    'file:../images/svg/poster.svg' => 1,
    'file:../images/svg/star.svg' => 1,
    'file:../images/svg/wallpaper.svg' => 1,
    'file:../images/svg/css.svg' => 1,
    'file:../images/svg/profile.svg' => 1,
    'file:../images/svg/chat_bell.svg' => 1,
    'file:../images/svg/notification_bell.svg' => 1,
    'file:../images/svg/user_online.svg' => 1,
    'file:../images/svg/spy.svg' => 1,
    'file:../images/svg/stats.svg' => 1,
    'file:../images/svg/voice_notes.svg' => 1,
    'file:../images/svg/plus.svg' => 1,
    'file:../images/svg/checkmark.svg' => 1,
    'file:../images/svg/upload.svg' => 1,
    'file:../images/svg/offers.svg' => 1,
    'file:../images/svg/live.svg' => 1,
    'file:../images/svg/delete.svg' => 1,
    'file:../images/svg/empty.svg' => 1,
    'file:../images/svg/ready.svg' => 1,
    'file:../images/svg/relationship.svg' => 1,
    'file:../images/svg/website.svg' => 1,
    'file:../images/svg/biography.svg' => 1,
    'file:../images/svg/work.svg' => 1,
    'file:../images/svg/location.svg' => 1,
    'file:../images/svg/education.svg' => 1,
    'file:../images/svg/username.svg' => 1,
    'file:../images/svg/design.svg' => 1,
    'file:../images/svg/funding.svg' => 1,
    'file:../images/svg/money-bag.svg' => 1,
    'file:../images/svg/transaction.svg' => 1,
    'file:../images/svg/paystack.svg' => 1,
    'file:../images/svg/header-menu.svg' => 1,
    'file:../images/svg/header-home.svg' => 1,
    'file:../images/svg/header-plus.svg' => 1,
    'file:../images/svg/header-friends.svg' => 1,
    'file:../images/svg/header-messages.svg' => 1,
    'file:../images/svg/header-notifications.svg' => 1,
    'file:../images/svg/header-search.svg' => 1,
    'file:../images/svg/playstore.svg' => 1,
    'file:../images/svg/playstore_badge.svg' => 1,
    'file:../images/svg/appstore.svg' => 1,
    'file:../images/svg/appstore_badge.svg' => 1,
    'file:../images/svg/appgallery.svg' => 1,
    'file:../images/svg/appgallery_badge.svg' => 1,
    'file:../images/svg/wasabi.svg' => 1,
  ),
),false)) {
function content_6251577053f5b1_92794204 (Smarty_Internal_Template $_smarty_tpl) {
?><div 
    class="svg-container <?php if ((isset($_smarty_tpl->tpl_vars['class']->value))) {
echo $_smarty_tpl->tpl_vars['class']->value;
}?>" 
    style="<?php if ((isset($_smarty_tpl->tpl_vars['width']->value))) {?>width:<?php echo $_smarty_tpl->tpl_vars['width']->value;?>
;<?php }?> <?php if ((isset($_smarty_tpl->tpl_vars['height']->value))) {?>height:<?php echo $_smarty_tpl->tpl_vars['height']->value;?>
;<?php }?> <?php if ((isset($_smarty_tpl->tpl_vars['style']->value))) {
echo $_smarty_tpl->tpl_vars['style']->value;
}?>">

    <?php if ($_smarty_tpl->tpl_vars['icon']->value == "2co") {?>

        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/2co.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "paypal") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/paypal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "credit_card") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/credit_card.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "alipay") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/alipay.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "bank") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/bank.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "bitcoin") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/bitcoin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "photos") {?>

    	<?php $_smarty_tpl->_subTemplateRender('file:../images/svg/photos.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "videos") {?>
    
    	<?php $_smarty_tpl->_subTemplateRender('file:../images/svg/videos.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "audios") {?>
    
    	<?php $_smarty_tpl->_subTemplateRender('file:../images/svg/audios.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "files") {?>
    
    	<?php $_smarty_tpl->_subTemplateRender('file:../images/svg/files.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "sun") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/sun.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "night") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/night.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "afternoon") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/sunrise.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "scroll_desktop") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/scroll_desktop.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "scroll_mobile") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/scroll_mobile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "chat") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/chat.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "settings") {?>

        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/settings.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "dashboard") {?>

        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/dashboard.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "24_hours") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/24_hours.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "trending") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/trending.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "memories") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/memories.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "language") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/language.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "posts_discover") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/posts_discover.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "popularity") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/popularity.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "posts_colored") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/posts_colored.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "posts_recent") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/posts_recent.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "social_share") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/social_share.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "youtube") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/youtube.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "piggy_bank") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/piggy_bank.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "adult") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/adult.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "watermark") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/watermark.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "jobs") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/jobs.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "google_recaptcha") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/google_recaptcha.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "censored") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/censored.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "fingerprint") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/fingerprint.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "hacker") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/hacker.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "firewall") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/firewall.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "chat_status") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/chat_status.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "chat_seen") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/chat_seen.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "chat_typing") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/chat_typing.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "call_video") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/call_video.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "call_audio") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/call_audio.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "aws_s3") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/aws_s3.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "digitalocean") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/digitalocean.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "ftp") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/ftp.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "sms") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/sms.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "twilio") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/twilio.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "infobip") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/infobip.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "bulksms") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/bulksms.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "msg91") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/msg91.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "email") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/email.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "email_notifications") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/email_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "email_smtp") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/email_smtp.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "login") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/login.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "ssl") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/ssl.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "smile") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/smile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "map") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/map.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "polls") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/polls.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "gif") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/gif.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "wall_posts") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/wall_posts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "verification") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/verification.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "age_limit") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/age_limit.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "getting_started") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/getting_started.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "account_activation") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/account_activation.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "pro_packages") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/pro_packages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "newsletter") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/newsletter.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "info_download") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/info_download.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "delete_user") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/delete_user.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "registration") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/registration.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "invitation") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/invitation.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "invite_friend") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/invite_friend.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "wallet") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/wallet.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "resolution") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/resolution.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "website_live") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/website_live.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "website_public") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/website_public.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "directory") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/directory.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "contat_us") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/contat_us.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "adblock") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/adblock.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "cookie") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/cookie.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "browser_notifications") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/browser_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "noty_notifications") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/noty_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "profile_notifications") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/profile_notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "gifts") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/gifts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "poke") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/poke.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "onesignal") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/onesignal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "like") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/like.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "comment") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/comment.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "share") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/share.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "developers") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/developers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "affiliates") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/affiliates.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "withdrawal") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/withdrawal.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "wallet_transfer") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/wallet_transfer.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "pages") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/pages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "groups") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/groups.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "events") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/events.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "blogs") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/blogs.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "market") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/market.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "products") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/products.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "forums") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/forums.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "ads") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/ads.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "movies") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/movies.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "games") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/games.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "find_people") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/find_people.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "saved") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/saved.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "articles") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/articles.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "boosted_pages") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/boosted_pages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "boosted_posts") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/boosted_posts.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "newsfeed") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/newsfeed.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "share_plugin") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/share_plugin.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "personal_info") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/personal_info.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "followings") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/followings.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "friends") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/friends.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "followers") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/followers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "search") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/search.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "folder") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/folder.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "database") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/database.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "full_backup") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/full_backup.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "album") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/album.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "write_article") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/write_article.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "music_file") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/music_file.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "night_mode") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/night_mode.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "user_night_mode") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/user_night_mode.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "poster") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/poster.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "star") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/star.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "wallpaper") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/wallpaper.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "css") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/css.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "profile") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/profile.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "chat_bell") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/chat_bell.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "notification_bell") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/notification_bell.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "user_online") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/user_online.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "spy") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/spy.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "stats") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/stats.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "voice_notes") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/voice_notes.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "plus") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/plus.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "checkmark") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/checkmark.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "upload") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/upload.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "offers") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/offers.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "live") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/live.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "delete") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/delete.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "empty") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/empty.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "ready") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/ready.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "relationship") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/relationship.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "website") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/website.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "biography") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/biography.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "work") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/work.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "location") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/location.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "education") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/education.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "username") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/username.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "design") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/design.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "funding") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/funding.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "money-bag") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/money-bag.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "transaction") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/transaction.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "paystack") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/paystack.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-menu") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-menu.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-home") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-home.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-plus") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-plus.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-friends") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-friends.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-messages") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-messages.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-notifications") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-notifications.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "header-search") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/header-search.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "playstore") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/playstore.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "playstore_badge") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/playstore_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "appstore") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/appstore.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "appstore_badge") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/appstore_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "appgallery") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/appgallery.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "appgallery_badge") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/appgallery_badge.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php } elseif ($_smarty_tpl->tpl_vars['icon']->value == "wasabi") {?>
    
        <?php $_smarty_tpl->_subTemplateRender('file:../images/svg/wasabi.svg', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

    <?php }?>
</div><?php }
}
