<?php
/* Smarty version 3.1.40, created on 2022-04-09 10:16:52
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/chat_typing.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62515d147486e3_99258175',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3b6f7a708f9862ff5de3fdd8042d2500035245a4' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/chat_typing.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62515d147486e3_99258175 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 58 57" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Page-1" fill="none" fill-rule="evenodd"><g id="046---Tying-Chats"><path id="Shape" d="m40 21h14c2.209139 0 4 1.790861 4 4v20c0 2.209139-1.790861 4-4 4h-3l.69 6.17c.0479682.4247282-.1793133.8329868-.5655965 1.015963-.3862831.1829763-.8461548.1002113-1.1444035-.205963l-6.98-6.98h-21c-2.209139 0-4-1.790861-4-4v-17z" fill="#3b97d3" fill-rule="nonzero"/><path id="Shape" d="m8 4h-4v4" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/><g fill-rule="nonzero"><path id="Shape" d="m40 4v20c0 2.209139-1.790861 4-4 4h-21l-6.98 6.98c-.29824873.3061743-.75812038.3889393-1.14440355.205963-.38628317-.1829762-.61356468-.5912348-.56559645-1.015963l.69-6.17h-3c-2.209139 0-4-1.790861-4-4v-20c0-2.209139 1.790861-4 4-4h32c2.209139 0 4 1.790861 4 4z" fill="#ff5364"/><path id="Shape" d="m54 46h-4c-.5522847 0-1-.4477153-1-1s.4477153-1 1-1h3v-3c0-.5522847.4477153-1 1-1s1 .4477153 1 1v4c0 .5522847-.4477153 1-1 1z" fill="#fff"/><circle id="Oval" cx="9" cy="14" fill="#fff" r="3"/><circle id="Oval" cx="31" cy="14" fill="#fff" r="3"/><circle id="Oval" cx="20" cy="14" fill="#fff" r="3"/><circle id="Oval" cx="27" cy="35" fill="#fff" r="3"/><circle id="Oval" cx="49" cy="35" fill="#fff" r="3"/><circle id="Oval" cx="38" cy="35" fill="#fff" r="3"/></g></g></g></svg><?php }
}
