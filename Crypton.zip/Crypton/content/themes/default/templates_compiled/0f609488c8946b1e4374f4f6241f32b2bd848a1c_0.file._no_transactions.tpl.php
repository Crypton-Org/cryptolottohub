<?php
/* Smarty version 3.1.40, created on 2022-04-10 08:02:23
  from '/home/nfrd7fewr696/public_html/content/themes/default/templates/_no_transactions.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62528f0f0b2af4_25896203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0f609488c8946b1e4374f4f6241f32b2bd848a1c' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/templates/_no_transactions.tpl',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:__svg_icons.tpl' => 1,
  ),
),false)) {
function content_62528f0f0b2af4_25896203 (Smarty_Internal_Template $_smarty_tpl) {
?><!-- no transaction -->
<div class="text-center text-muted">
    <?php $_smarty_tpl->_subTemplateRender('file:__svg_icons.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('icon'=>"transaction",'class'=>"mb20",'width'=>"96px",'height'=>"96px"), 0, false);
?>
    <div class="text-md">
        <span style="padding: 8px 20px; background: #ececec; border-radius: 18px; font-weight: bold;"><?php echo __("Looks like you don't have any transaction yet");?>
</span>
    </div>
</div>
<!-- no transaction --><?php }
}
