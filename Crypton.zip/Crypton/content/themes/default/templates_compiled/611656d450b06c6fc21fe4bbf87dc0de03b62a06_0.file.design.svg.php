<?php
/* Smarty version 3.1.40, created on 2022-04-09 10:07:01
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/design.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62515ac5d55600_48898952',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '611656d450b06c6fc21fe4bbf87dc0de03b62a06' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/design.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62515ac5d55600_48898952 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#FFD400;" d="M91.159,184.138C37.731,211.48,0,266.974,0,331c0,90.981,75.019,165,166,165
	c33.203,0,64.089-9.944,90-26.887l-49.376-197.225L91.159,184.138z"/>
<path style="fill:#00ABE9;" d="M420.841,184.138l-115.308,87.48L256,469.113C281.911,486.056,312.797,496,346,496
	c90.981,0,166-74.019,166-165C512,266.974,474.269,211.48,420.841,184.138z"/>
<path style="fill:#FF3997;" d="M421,181c0,1.199,0,2.1-0.3,2.999l-164.7,60l-164.7-60C91,183.1,91,182.199,91,181
	c0-90.901,74.099-165,165-165S421,90.099,421,181z"/>
<path style="fill:#F50B75;" d="M421,181c0,1.199,0,2.1-0.3,2.999l-164.7,60V16C346.901,16,421,90.099,421,181z"/>
<path style="fill:#54E360;" d="M331,331c0,57.9-30,108.6-75,137.999C211,439.6,181,388.9,181,331c0-1.199,0-2.1,0.3-2.999h149.4
	C331,328.9,331,329.801,331,331z"/>
<path style="fill:#FF9100;" d="M166,166c-26.955,0-52.346,6.627-74.841,18.138c1.188,62.69,37.456,116.834,90,143.723L256,192.887
	C230.089,175.944,199.203,166,166,166z"/>
<path style="fill:#A24BDB;" d="M346,166c-33.203,0-64.089,9.944-90,26.887l74.841,134.974c52.544-26.889,88.812-81.033,90-143.723
	C398.346,172.627,372.955,166,346,166z"/>
<path style="fill:#00CC71;" d="M330.7,328.001c0.3,0.899,0.3,1.8,0.3,2.999c0,57.9-30,108.6-75,137.999V328.001H330.7z"/>
<path style="fill:#5A5A5A;" d="M330.7,328.001C308.2,339.401,283.001,346,256,346s-52.2-6.599-74.7-17.999
	c0.899-56.7,30.3-106.201,74.7-135C300.399,221.8,329.801,271.3,330.7,328.001z"/>
<path style="fill:#444444;" d="M330.7,328.001C308.2,339.401,283.001,346,256,346V193.001
	C300.399,221.8,329.801,271.3,330.7,328.001z"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
