<?php
/* Smarty version 3.1.40, created on 2022-04-09 10:05:02
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/account_activation.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62515a4e2296c5_26754242',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '625d6a6c3b86b50c9c6fc74d5b1f1a2a37947f87' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/account_activation.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62515a4e2296c5_26754242 (Smarty_Internal_Template $_smarty_tpl) {
?><svg id="Capa_1" enable-background="new 0 0 504.5 504.5" height="512" viewBox="0 0 504.5 504.5" width="512" xmlns="http://www.w3.org/2000/svg"><path d="m496.885 94.865h-30v314.77h30c4.705-4.705 7.615-11.205 7.615-18.385v-278c0-7.18-2.91-13.68-7.615-18.385z" fill="#4fdbff"/><path d="m474.5 113.25c0-7.18-2.91-13.68-7.615-18.385h-391.77c-4.705 4.705-7.615 11.205-7.615 18.385v278c0 7.18 2.91 13.68 7.615 18.385h391.77c4.705-4.705 7.615-11.205 7.615-18.385z" fill="#8ae7ff"/><path d="m474.5 387.25-26 30h30c7.18 0 13.68-2.91 18.385-7.615z" fill="#14cfff"/><path d="m474.5 391.25v-4l-188.5-188.5-210.885 210.885c4.705 4.705 11.205 7.615 18.385 7.615h355c14.359 0 26-11.641 26-26z" fill="#4fdbff"/><path d="m478.5 87.25h-30l26 30 22.385-22.385c-4.705-4.705-11.205-7.615-18.385-7.615z" fill="#8ae7ff"/><path d="m448.5 87.25h-355c-7.18 0-13.68 2.91-18.385 7.615l173.762 173.762c20.503 20.502 53.744 20.503 74.246 0l151.377-151.377v-4c0-14.359-11.641-26-26-26z" fill="#c4f3ff"/><path d="m127.5 259.75h-120c-4.142 0-7.5-3.357-7.5-7.5s3.358-7.5 7.5-7.5h120c4.142 0 7.5 3.357 7.5 7.5s-3.358 7.5-7.5 7.5z" fill="#3a6fd8"/><g fill="#3b88f5"><path d="m97.5 199.75h-90c-4.142 0-7.5-3.357-7.5-7.5s3.358-7.5 7.5-7.5h90c4.142 0 7.5 3.357 7.5 7.5s-3.358 7.5-7.5 7.5z"/><path d="m97.5 319.75h-90c-4.142 0-7.5-3.357-7.5-7.5s3.358-7.5 7.5-7.5h90c4.142 0 7.5 3.357 7.5 7.5s-3.358 7.5-7.5 7.5z"/></g></svg><?php }
}
