<?php
/* Smarty version 3.1.40, created on 2022-04-09 11:54:12
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/money-bag.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_625173e4f2b039_02286478',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '068f0f993f0187c1e11ab15207114e950f508a86' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/money-bag.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_625173e4f2b039_02286478 (Smarty_Internal_Template $_smarty_tpl) {
?><svg height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g id="Flat"><path d="m344 96v-24a16 16 0 0 0 -16-16h-32v40z" fill="#966342"/><path d="m416 456h-128a72 72 0 0 1 -72-72v-.00014a320.18968 320.18968 0 0 1 30.82216-137.06886l28.17433-59.47915a48 48 0 0 1 43.37942-27.45185h67.24818a48 48 0 0 1 43.37942 27.45186l28.17433 59.47914a320.18968 320.18968 0 0 1 30.82216 137.06886v.00014a72 72 0 0 1 -72 72z" fill="#ad7d4d"/><rect fill="#396795" height="32" rx="16" width="96" x="304" y="128"/><path d="m424 72v24a32.004 32.004 0 0 1 -32 32h-80a32.004 32.004 0 0 1 -32-32v-24a16 16 0 1 1 32 0 24.002 24.002 0 0 0 24 24h8a24.00619 24.00619 0 0 0 24-24 15.97853 15.97853 0 0 1 16-16h24a15.99555 15.99555 0 0 1 16 16z" fill="#ad7d4d"/><path d="m400 88v8a47.7529 47.7529 0 0 1 -12.25 32h-35.75a32.02965 32.02965 0 0 0 32-32v-8z" fill="#966342"/><path d="m384 248v-4a28.03941 28.03941 0 0 0 -24-27.70978v-16.29022h-16v16.29022a27.99837 27.99837 0 0 0 4 55.70978h8a12 12 0 0 1 0 24h-8a12.01375 12.01375 0 0 1 -12-12v-4h-16v4a28.03941 28.03941 0 0 0 24 27.70972v16.29028h16v-16.29028a27.99834 27.99834 0 0 0 -4-55.70972h-8a12 12 0 0 1 0-24h8a12.01375 12.01375 0 0 1 12 12v4z" fill="#eedc9a"/><path d="m232 384h112v72h-112z" fill="#008051"/><path d="m320 416h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#067045"/><path d="m320 440h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#067045"/><path d="m272 416h-40a8 8 0 0 1 0-16h40a8 8 0 0 1 0 16z" fill="#067045"/><path d="m272 440h-40a8 8 0 0 1 0-16h40a8 8 0 0 1 0 16z" fill="#067045"/><path d="m272 384h32v72h-32z" fill="#eebe33"/><path d="m88 312h208v72h-208z" fill="#349966"/><path d="m88 312h96v72h-96z" fill="#4ba477"/><path d="m272 344h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#008051"/><path d="m184 376h112v8h-112z" fill="#008051"/><path d="m272 368h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#008051"/><path d="m224 312h32v72h-32z" fill="#eebe33"/><path d="m200 344h-88a8 8 0 0 1 0-16h88a8 8 0 0 1 0 16z" fill="#349966"/><path d="m200 368h-88a8 8 0 0 1 0-16h88a8 8 0 0 1 0 16z" fill="#349966"/><path d="m184 296a16 16 0 0 0 16 16h-96a16 16 0 0 1 -16-16 16 16 0 0 1 16-16h96a16 16 0 0 0 -16 16z" fill="#4ba477"/><path d="m200 312h-96a15.99559 15.99559 0 0 1 -16-16h96a15.99559 15.99559 0 0 0 16 16z" fill="#349966"/><path d="m24 384h208v72h-208z" fill="#349966"/><path d="m24 384h96v72h-96z" fill="#4ba477"/><path d="m208 416h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#008051"/><path d="m208 440h-16a8 8 0 0 1 0-16h16a8 8 0 0 1 0 16z" fill="#008051"/><path d="m160 384h32v72h-32z" fill="#eebe33"/><path d="m136 416h-88a8 8 0 0 1 0-16h88a8 8 0 0 1 0 16z" fill="#349966"/><path d="m136 440h-88a8 8 0 0 1 0-16h88a8 8 0 0 1 0 16z" fill="#349966"/><g fill="#008051"><path d="m184 328h16a8 8 0 0 1 8 8 8 8 0 0 1 -8 8h-16a0 0 0 0 1 0 0v-16a0 0 0 0 1 0 0z"/><path d="m184 352h16a8 8 0 0 1 8 8 8 8 0 0 1 -8 8h-16a0 0 0 0 1 0 0v-16a0 0 0 0 1 0 0z"/><path d="m120 400h16a8 8 0 0 1 8 8 8 8 0 0 1 -8 8h-16a0 0 0 0 1 0 0v-16a0 0 0 0 1 0 0z"/><path d="m120 424h16a8 8 0 0 1 8 8 8 8 0 0 1 -8 8h-16a0 0 0 0 1 0 0v-16a0 0 0 0 1 0 0z"/></g><path d="m88 376h96v8h-96z" fill="#349966"/></g></svg><?php }
}
