<?php
/* Smarty version 3.1.40, created on 2022-04-09 09:59:04
  from '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/youtube.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_625158e81afe37_64938256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61b081cce10bb9bc3635b3f918b9048d5012e7d0' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/images/svg/youtube.svg',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_625158e81afe37_64938256 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#303C42;" d="M469.333,64H42.667C19.146,64,0,83.135,0,106.667v256c0,23.531,19.146,42.667,42.667,42.667h426.667
	c23.521,0,42.667-19.135,42.667-42.667v-256C512,83.135,492.854,64,469.333,64z"/>
<path style="fill:#E53935;" d="M490.667,362.667c0,11.76-9.563,21.333-21.333,21.333H42.667c-11.771,0-21.333-9.573-21.333-21.333
	v-256c0-11.76,9.563-21.333,21.333-21.333h426.667c11.771,0,21.333,9.573,21.333,21.333V362.667z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M469.333,85.333v198.635c0,36.099-29.264,65.365-65.365,65.365H21.333
	v13.333c0,11.76,9.563,21.333,21.333,21.333h426.667c11.771,0,21.333-9.573,21.333-21.333v-256
	C490.667,94.906,481.104,85.333,469.333,85.333z"/>
<path style="fill:#E53935;" d="M373.333,426.667H138.667c-5.896,0-10.667,4.771-10.667,10.667S132.771,448,138.667,448h234.667
	c5.896,0,10.667-4.771,10.667-10.667S379.229,426.667,373.333,426.667z"/>
<path style="fill:#303C42;" d="M208.042,150.781c-3.292-1.896-7.354-1.927-10.688-0.031c-3.313,1.906-5.354,5.427-5.354,9.25
	v149.333c0,3.823,2.042,7.344,5.354,9.25c1.646,0.948,3.479,1.417,5.313,1.417c1.854,0,3.708-0.49,5.375-1.448l128-74.667
	c3.271-1.917,5.292-5.427,5.292-9.219s-2.021-7.302-5.292-9.219L208.042,150.781z"/>
<polygon style="fill:#FFFFFF;" points="213.333,290.76 213.333,178.573 309.5,234.667 "/>
<polygon style="opacity:0.1;enable-background:new    ;" points="213.333,290.76 213.333,233.333 309.5,234.667 "/>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="-47.0278" y1="641.2312" x2="-22.3785" y2="629.7375" gradientTransform="matrix(21.3333 0 0 -21.3333 996.3334 13791.667)">
	<stop  offset="0" style="stop-color:#FFFFFF;stop-opacity:0.2"/>
	<stop  offset="1" style="stop-color:#FFFFFF;stop-opacity:0"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M373.333,426.667H138.667c-5.896,0-10.667,4.771-10.667,10.667S132.771,448,138.667,448
	h234.667c5.896,0,10.667-4.771,10.667-10.667S379.229,426.667,373.333,426.667z M469.333,64H42.667C19.146,64,0,83.135,0,106.667
	v256c0,23.531,19.146,42.667,42.667,42.667h426.667c23.521,0,42.667-19.135,42.667-42.667v-256C512,83.135,492.854,64,469.333,64z"
	/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
