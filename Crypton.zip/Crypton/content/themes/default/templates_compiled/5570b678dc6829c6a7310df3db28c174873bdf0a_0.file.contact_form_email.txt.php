<?php
/* Smarty version 3.1.40, created on 2022-04-09 13:37:33
  from '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/contact_form_email.txt' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62518c1ded3a08_57055635',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5570b678dc6829c6a7310df3db28c174873bdf0a' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/contact_form_email.txt',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62518c1ded3a08_57055635 (Smarty_Internal_Template $_smarty_tpl) {
echo __("Hi");?>
,

<?php echo __("You have a new email message");?>


<?php echo __("Email Subject");?>
: <?php echo $_smarty_tpl->tpl_vars['_POST']->value['subject'];?>


<?php echo __("Sender Name");?>
: <?php echo $_smarty_tpl->tpl_vars['_POST']->value['name'];?>


<?php echo __("Sender Email");?>
: <?php echo $_smarty_tpl->tpl_vars['_POST']->value['email'];?>


<?php echo __("Email Message");?>
: <?php echo $_smarty_tpl->tpl_vars['_POST']->value['message'];?>


<?php echo $_smarty_tpl->tpl_vars['system']->value['system_title'];?>
 <?php echo __("Team");
}
}
