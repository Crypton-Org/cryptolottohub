<?php
/* Smarty version 3.1.40, created on 2022-04-09 13:28:28
  from '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/notification_email.txt' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_625189fc632788_42016012',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7c3edc6eb6a4c2d7a065d09519946d9ea7847d53' => 
    array (
      0 => '/home/nfrd7fewr696/public_html/content/themes/default/templates/emails/notification_email.txt',
      1 => 1638145102,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_625189fc632788_42016012 (Smarty_Internal_Template $_smarty_tpl) {
echo __("Hi");?>
 <?php echo $_smarty_tpl->tpl_vars['receiver']->value['name'];?>
,

<?php echo $_smarty_tpl->tpl_vars['user']->value->_data['name'];?>
 <?php echo $_smarty_tpl->tpl_vars['notification']->value['message'];?>

<?php echo $_smarty_tpl->tpl_vars['notification']->value['url'];?>


<?php echo $_smarty_tpl->tpl_vars['system']->value['system_title'];?>
 <?php echo __("Team");
}
}
